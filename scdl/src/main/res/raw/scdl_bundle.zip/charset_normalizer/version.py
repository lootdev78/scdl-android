"""
Expose version
"""

from __future__ import annotations

__version__ = "3.4.9"
VERSION = __version__.split(".")
